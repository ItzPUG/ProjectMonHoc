<?php
session_start();
require 'conn/connect.php';

// Kiểm tra xem admin đã đăng nhập chưa
if (!isset($_SESSION['type']) || $_SESSION['type'] !== 'admin') {
    header('Location: login.php');
    exit();
}

// Lấy `order_id` và `status` từ query string
if (isset($_GET['order_id']) && isset($_GET['status'])) {
    $order_id = intval($_GET['order_id']);
    $status = $_GET['status'];

    // Chỉ cho phép cập nhật sang "Order Placed" hoặc "Cancelled"
    if (in_array($status, ['Order Placed', 'Cancelled'])) {
        // Update trạng thái đơn hàng
        $sql = "UPDATE orders SET orderstatus = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('si', $status, $order_id);

        if ($stmt->execute()) {
            // Thông báo và quay lại trang quản lý đơn hàng
            echo "<script>
                    alert('Trạng thái đơn hàng đã được cập nhật thành \"$status\".');
                    window.location.href = 'ad-order.php';
                  </script>";
        } else {
            // Thông báo lỗi nếu không cập nhật được
            echo "<script>
                    alert('Failed to update order status.');
                    window.location.href = 'ad-order.php';
                  </script>";
        }
        $stmt->close();
    } else {
        // Trạng thái không hợp lệ
        echo "<script>
                alert('Invalid status provided.');
                window.location.href = 'ad-order.php';
              </script>";
    }
} else {
    // Thiếu `order_id` hoặc `status`
    header('Location: ad-order.php');
    exit();
}

$conn->close();
?>
