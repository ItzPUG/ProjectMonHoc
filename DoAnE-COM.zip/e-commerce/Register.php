<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng Ký</title>
    <script>
        function validatePassword() {
            var password = document.getElementById("password").value;
            var repassword = document.getElementById("repassword").value;   
            var message = document.getElementById("error-message");   

            if (password === repassword) {
                message.textContent = ""; // Clear the error message
                return true; // Allow form submission
            } else {
                message.textContent = "Mật khẩu không khớp!"; // Show error message
                return false; // Prevent form submission
            }
        }
    </script>
</head>
<body>

<?php
session_start();
include('C:/xampp/htdocs/e-commerce/conn/connect.php'); 
include('C:/xampp/htdocs/e-commerce/template/header.php'); 
include('C:/xampp/htdocs/e-commerce/template/nav.php');

$mess = ""; // Khởi tạo biến thông báo

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $u = $_POST['username'];
    $p = password_hash($_POST['password'], PASSWORD_DEFAULT); // Mã hóa pass
    $e = $_POST['email'];

    // Kiểm tra username hoặc email đã tồn tại hay chưa
    $sql = "SELECT * FROM users WHERE username = '$u' OR email = '$e'"; 
    $res = mysqli_query($conn, $sql);

    if (mysqli_num_rows($res) > 0) {
        $mess = "Username hoặc email đã tồn tại!"; // Cập nhật thông báo lỗi nếu username hoặc email đã tồn tại
    } else {
        // Chèn dữ liệu nếu không trùng
        $sql = "INSERT INTO users (username, password, email, type) VALUES ('$u', '$p', '$e', 'member')"; 
        $res = mysqli_query($conn, $sql);

        if ($res) {
            $mess = "Đăng ký thành công!";
        } else {
            $mess = "Đăng ký thất bại!";
        }
    }
}
?>

<div class="container">
    <div style="width: 50%; margin: 0 auto;">
        <img src="https://i.imgur.com/WpsqQq3.gif" alt="LoginImage" style="width:550px;height:200px;">
        <div style="width: 300px; margin-left: 200px; margin-right: auto;">
            <h1><b><i>Đăng Kí</i></b></h1>
        </div>
        <form action="" method="POST" onsubmit="return validatePassword()">
            <div class="form-group">
                <label for="username">Tên Đăng Nhập:</label>
                <input type="text" class="form-control" placeholder="Enter Username" name="username" required> 
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" class="form-control" placeholder="Enter email" name="email" required> 
            </div>

            <div class="form-group">
                <label for="pwd">Nhập mật khẩu:</label>
                <input type="password" class="form-control" placeholder="Enter password" name="password" id="password" required>
            </div>
            <div class="form-group">
                <label for="pwd">Nhập lại mật khẩu:</label>
                <input type="password" class="form-control" placeholder="Enter Repassword" name="repassword" id="repassword" required>
                <span id="error-message" class="error" style="color: red;"></span><br><br>
                <?php
                if (isset($mess) && $mess!=""){
                ?>
                <div class="alert alert-success">
                    <strong>Info!</strong> <?php echo $mess?>.
                </div>
                <?php
                }
                ?>
            </div>
            <div style="margin: 0 auto;">
                <button type="submit" class="btn btn-primary">Đăng kí</button> <a href="login.php" class="btn btn-info">Login</a>
            </div>
        </form>
    </div>
</div>

<?php
include('C:/xampp/htdocs/e-commerce/template/footer.php');
?>

</body>
</html>
