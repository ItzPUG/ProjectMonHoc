<?php
session_start();
include('conn/connect.php');
include('template/header.php');
include('template/nav.php');

// Kiểm tra nếu người dùng không phải admin
if (!isset($_SESSION['type']) || $_SESSION['type'] !== 'admin') {
    header("Location: index.php"); // Chuyển hướng về trang chủ
    exit();
}
?>
<style>
/* Định dạng hình ảnh */
.image-container {
    width: 200px;
    height: 200px;
    overflow: hidden;
    margin: 0 auto;
}

.image-container img {
    width: 100%;
    height: 100%;
    object-fit: contain;
}

/* Định dạng phần caption */
.caption {
    text-align: center; /* Căn giữa nội dung trong caption */
    margin-top: 10px;
}

/* Định dạng cho các nút */
.caption .btn-group {
    display: flex; /* Đặt các nút theo hàng ngang */
    justify-content: center; /* Căn giữa các nút */
    gap: 10px; /* Tạo khoảng cách giữa các nút */
}

.caption h4 {
    font-size: 18px;
    font-weight: bold;
    margin-bottom: 5px;
}

.caption p {
    margin: 5px 0;
}
.qlysp{
    text-align: center;
    color: blue;
}
</style>

<div class="container">
    <h1 class="qlysp">Quản lý sản phẩm</h1>
    <div class="text-left mb-3">
        <a href="addproduct.php" class="btn btn-success">Thêm sản phẩm mới</a>
    </div>
    <br></br>
    <div class="row">
        <?php
        // Truy vấn danh sách sản phẩm
        $sql = "SELECT * FROM products";
        $res = mysqli_query($conn, $sql);

        if ($res && mysqli_num_rows($res) > 0) {
            while ($r = mysqli_fetch_array($res)) {
                ?>
                <div class="col-sm-6 col-md-3">
                    <div class="image-container">
                        <img src="images/<?php echo htmlspecialchars($r['image']) ?>" class="rounded" alt="<?php echo htmlspecialchars($r['title']) ?>">
                    </div>
                    <div class="caption">
                        <h4><?php echo htmlspecialchars($r['title']) ?></h4>
                        <p>Giá: <?php echo htmlspecialchars($r['price']) ?> USD</p>
                        <div class="btn-group">
                            <a href="editproduct.php?id=<?php echo $r['id'] ?>" class="btn btn-warning btn-sm">Sửa</a>
                            <a href="deleteproduct.php?id=<?php echo $r['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Bạn có chắc chắn muốn xóa sản phẩm này không?')">Xóa</a>
                        </div>
                    </div>
                </div>
                <?php
            }
        } else {
            echo "<p class='text-center'>Không tìm thấy sản phẩm nào.</p>";
        }
        ?>
    </div>
</div>


<?php
include('template/footer.php');
?>
