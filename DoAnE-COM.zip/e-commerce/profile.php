<?php
session_start();
require 'conn/connect.php'; 
include 'template/header.php'; 
include 'template/nav.php';

if (isset($_SESSION['user_id'])) {

    $id = intval($_SESSION['user_id']);
    $sql = "SELECT * FROM users WHERE id = $id"; 
    $res = mysqli_query($conn, $sql);
    $user = $res->fetch_assoc();
    $username = $user['username']; 
    $email = $user['email'];
    $user_password = $user['password'];
} else {
    header ('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') { 
    $new_email = $_POST['email'];
    $old_password = $_POST['old_password']; 
    $new_password = $_POST['new_password'];
    
    // Kiểm tra email có bị trùng hay không (ngoại trừ email của chính người dùng hiện tại)
    $email_check_sql = "SELECT * FROM users WHERE email = '$new_email' AND id != $id";
    $email_check_res = mysqli_query($conn, $email_check_sql);

    if (mysqli_num_rows($email_check_res) > 0) {
        $mess = "Email đã tồn tại!";
    } else {
        // Xác nhận mật khẩu cũ
        if (password_verify($old_password, $user_password)) {
            // Mã hóa mật khẩu mới (nếu có)
            if (!empty($new_password)) {
                $new_hashed_password = password_hash($new_password, PASSWORD_DEFAULT); // Mã hóa mật khẩu mới
            } else {
                $new_hashed_password = $user_password; // Giữ mật khẩu cũ
            }

            // Cập nhật email và mật khẩu
            $sql = "UPDATE users SET email = '$new_email', password = '$new_hashed_password' WHERE id = $id"; 
            $result = mysqli_query($conn, $sql);

            if ($result) {
                $mess = "Cập nhật thành công";
            } else {
                $mess = "Cập nhật không thành công";
            }
        } else {
            $mess = "Sai mật khẩu";
        }
    }
}
?>
<div class="container">
    <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8">
            <h2 style="background-color: red; color: white; padding: 5px; text-align: center;">Cập nhật thông tin người dùng</h2>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th colspan="2" class="text-center" style="background-color: #f2f2f2;">Thông tin cập nhật</th>
                    </tr>
                </thead>
                <tbody>
                    <form action="" method="POST">
                        <tr>
                            <td><label for="username">Username:</label></td>
                            <td><input type="text" class="form-control" id="username" value="<?= $username ?>" disabled></td>
                        </tr>
                        <tr>
                            <td><label for="email">Email address:</label></td>
                            <td><input type="email" class="form-control" placeholder="Enter email" name="email" value="<?= $email ?>"></td>
                        </tr>
                        <tr>
                            <td><label for="oldpwd">Old Password:</label></td>
                            <td><input type="password" class="form-control" placeholder="Enter old password" name="old_password" required></td>
                        </tr>
                        <tr>
                            <td><label for="newpwd">New Password:</label></td>
                            <td><input type="password" class="form-control" placeholder="Enter new password" name="new_password"></td>
                        </tr>
                        <tr>
                            <td colspan="2" class="text-center">
                                <button type="submit" class="btn btn-primary">Update</button>
                            </td>
                        </tr>
                    </form>
                </tbody>
            </table>
            <?php
            if (isset($mess) && $mess != "") {
            ?>
            <div class="alert alert-danger">
                <strong>Info!</strong> <?php echo $mess?>.
            </div>
            <?php
            }
            ?>
        </div>
    </div>
</div>

<?php
$conn->close();
include 'template/footer.php';
?>
