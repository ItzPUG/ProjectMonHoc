<?php
session_start();
require 'conn/connect.php';

// Kiểm tra xem người dùng đã đăng nhập chưa
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$total_price = 0;

if (isset($_POST) && !empty($_POST) && isset($_POST['agree']) && $_POST['agree'] == true) {
    // Lấy thông tin từ form thanh toán
    $country = $_POST['country'];
    $firstname = $_POST['fname'];
    $lastname = $_POST['lname'];
    $company = $_POST['company'];
    $address1 = $_POST['address1'];
    $address2 = $_POST['address2'];
    $city = $_POST['city'];
    $state = $_POST['state'];
    $zip = $_POST['zipcode'];
    $mobile = $_POST['phone'];
    $payment = $_POST['payment'];

    // Kiểm tra và lưu thông tin người dùng vào bảng `usersmeta`
    $sql_sel = "SELECT * FROM usersmeta WHERE user_id = $user_id";
    $res = mysqli_query($conn, $sql_sel);
    $count = mysqli_num_rows($res);

    if ($count == 1) {
        // Cập nhật thông tin người dùng nếu đã tồn tại
        $sql_usersmeta = "UPDATE usersmeta SET 
            country = '$country', 
            firstname = '$firstname', 
            lastname = '$lastname', 
            company = '$company', 
            address1 = '$address1', 
            address2 = '$address2', 
            city = '$city', 
            state = '$state', 
            zip = '$zip', 
            mobile = '$mobile' 
            WHERE user_id = $user_id";
    } else {
        // Thêm mới thông tin người dùng
        $sql_usersmeta = "INSERT INTO usersmeta 
            (country, firstname, lastname, company, address1, address2, city, state, zip, mobile, user_id)
            VALUES ('$country', '$firstname', '$lastname', '$company', '$address1', '$address2', '$city', '$state', '$zip', '$mobile', $user_id)";
    }
    $res_usersmeta = mysqli_query($conn, $sql_usersmeta);

    if ($res_usersmeta) {
        // Tính tổng giá trị đơn hàng
        $selected_items = json_decode($_POST['array'], true); // Giải mã JSON thành mảng PHP
        foreach ($selected_items as $item) {
            list($product_id, $product_name, $quantity, $price) = explode('|', $item);
            $total_price += $quantity * $price;
        }

        // Thêm đơn hàng vào bảng `orders`
        $order_status = ($payment == "pal") ? "Pending" : "Order Placed";
        $sql_order = "INSERT INTO orders (user_id, totalprice, paymentmode, orderstatus) 
                      VALUES ($user_id, $total_price, '$payment', '$order_status')";
        $res_order = mysqli_query($conn, $sql_order);

        if ($res_order) {
            $order_id = mysqli_insert_id($conn);

            // Thêm sản phẩm vào bảng `orderitems`
            foreach ($selected_items as $item) {
                list($product_id, $product_name, $quantity, $price) = explode('|', $item);
                $sql_orderitems = "INSERT INTO orderitems (order_id, product_id, product_quantity, product_price) 
                                   VALUES ($order_id, $product_id, $quantity, $price)";
                mysqli_query($conn, $sql_orderitems);

                // Xóa sản phẩm khỏi giỏ hàng
                $sql_cart = "DELETE FROM cart WHERE user_id = $user_id AND product_id = $product_id";
                mysqli_query($conn, $sql_cart);
            }

            if ($payment == "cod") {
                // Thanh toán khi nhận hàng
                header('Location: my-order.php');
                exit();
            } elseif ($payment == "pal") {
                // Thanh toán qua PayPal
                ?>
                <form action="https://www.sandbox.paypal.com/cgi-bin/webscr" method="post" id="paypalForm">
                    <input type="hidden" name="business" value="sb-wuopw34262589@business.example.com">
                    <input type="hidden" name="cmd" value="_xclick">
                    <input type="hidden" name="item_name" value="HoaDonMuaHang">
                    <input type="hidden" name="amount" value="<?php echo $total_price; ?>">
                    <input type="hidden" name="currency_code" value="USD">
                    <input type="hidden" name="custom" value="<?php echo $order_id; ?>">
                    <input type="hidden" name="return" value="http://localhost/e-commerce/paypal-success.php">
                    <input type="hidden" name="cancel_return" value="http://localhost/e-commerce/paypal-cancel.php?order_id=<?php echo $order_id; ?>">
                </form>
                <script>
                    document.getElementById("paypalForm").submit();
                </script>
                <?php
                exit();
            }
        } else {
            echo "Lỗi khi thêm đơn hàng.";
        }
    } else {
        echo "Lỗi khi cập nhật thông tin khách hàng.";
    }
} else {
    header('Location: card.php');
    exit();
}
?>
