<?php
session_start();
require 'conn/connect.php';

if (isset($_POST['custom'])) {
    $order_id = intval($_POST['custom']);

    // Kiểm tra giao dịch PayPal (giả lập)
    $payment_status = "Success"; // Giả lập trạng thái. Thực tế, bạn cần tích hợp API IPN của PayPal.

    if ($payment_status == "Success") {
        $sql_update = "UPDATE orders SET orderstatus = 'Order Placed' WHERE id = $order_id";
        mysqli_query($conn, $sql_update);

        echo "<script>alert('Thanh toán thành công! Đơn hàng của bạn đã được đặt.'); window.location.href = 'my-order.php';</script>";
    } else {
        echo "<script>alert('Lỗi thanh toán! Vui lòng thử lại.'); window.location.href = 'card.php';</script>";
    }
} else {
    echo "<script>alert('Dữ liệu không hợp lệ!'); window.location.href = 'card.php';</script>";
}
?>
