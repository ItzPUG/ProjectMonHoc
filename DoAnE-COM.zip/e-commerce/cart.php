<?php
session_start();
include 'template/header.php';
include 'template/nav.php';
?>
<div class="container">
    <div class="row">
        <table class="table">
            <tr>
                <th>S.Number</th>
                <th>Item Name</th>
                <th>Price</th>
                <th>Action</th>
            </tr>
            <tr>
                <td>1</td>
                <td>Title</td>
                <td>$500</td>
                <td>
                    <a href="delcart.php?remove=">Remove</a>
                </td>
            </tr>
            <tr>
                <th>Total</th>
                <th></th>
                <th>$500</th>
                <th><a href="#" class="btn btn-info">Checkout</a></th>
            </tr>
        </table>
    </div>
</div>