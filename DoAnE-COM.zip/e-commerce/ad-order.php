<?php
session_start();
require 'conn/connect.php';

// Kiểm tra quyền admin
if (!isset($_SESSION['type']) || $_SESSION['type'] !== 'admin') {
    header("Location: index.php");
    exit();
}

include 'template/header.php';
include 'template/nav.php';

// Lấy danh sách các đơn hàng và thông tin khách hàng
$sql = "
    SELECT 
        o.id AS order_id,
        o.timestamp AS order_date,
        o.orderstatus AS status,
        o.totalprice AS total_price,
        o.paymentmode AS payment_method,
        u.username AS customer_name,
        u.email AS customer_email
    FROM orders o
    JOIN users u ON o.user_id = u.id
    ORDER BY o.timestamp DESC";
$stmt = $conn->prepare($sql);
$stmt->execute();
$result = $stmt->get_result();
?>
<script>
    function updateOrderStatus(orderId, status) {
        const confirmationMessage = status === "Cancelled" 
            ? "Bạn có chắc chắn muốn hủy đơn hàng này không?" 
            : "Bạn có chắc chắn muốn khôi phục đơn hàng này không?";
        if (confirm(confirmationMessage)) {
            window.location.href = 'ad-cancelorder.php?order_id=' + orderId + '&status=' + status;
        }
    }
</script>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Orders - Admin</title>
    <style>
        .container { margin-top: 30px; }
        .donhang { text-align: center; margin-bottom: 20px; color: #007bff; }
        .table th, .table td { text-align: center; vertical-align: middle; }
        .table th { background-color: #f8f9fa; }
        .btn-view, .btn-cancel, .btn-restore {
            text-decoration: none; padding: 5px 10px; border-radius: 5px; color: white;
        }
        .btn-view { background-color: #28a745; }
        .btn-cancel { background-color: #dc3545; }
        .btn-restore { background-color: #007bff; }
        .btn-view:hover, .btn-cancel:hover, .btn-restore:hover { opacity: 0.8; }
    </style>
</head>
<body>

<div class="container">
    <h1 class="donhang">Danh sách quản lý đơn hàng</h1>
    <table class="table table-striped table-bordered">
        <thead>
            <tr>
                <th>ID đơn hàng</th>
                <th>Khách hàng</th>
                <th>Email</th>
                <th>Ngày giao dịch</th>
                <th>Trạng thái đơn hàng</th>
                <th>Phương thức thanh toán</th>
                <th>Tổng giá</th>
                <th>Hành động</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row['order_id'] . "</td>";
                    echo "<td>" . $row['customer_name'] . "</td>";
                    echo "<td>" . $row['customer_email'] . "</td>";
                    echo "<td>" . $row['order_date'] . "</td>";
                    echo "<td>" . $row['status'] . "</td>";
                    echo "<td>" . $row['payment_method'] . "</td>";
                    echo "<td>" . $row['total_price'] . " USD</td>";
                    echo "<td>";
                    echo "<a href='ad-vieworder.php?order_id=" . $row['order_id'] . "' class='btn-view'>View</a> | ";
                    if ($row['status'] === 'Cancelled') {
                        echo "<button class='btn-restore' onclick='updateOrderStatus(" . $row['order_id'] . ", \"Order Placed\")'>Restore</button>";
                    } else {
                        echo "<button class='btn-cancel' onclick='updateOrderStatus(" . $row['order_id'] . ", \"Cancelled\")'>Cancel</button>";
                    }
                    echo "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='8'>No orders found</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>

</body>
</html>

<?php
$stmt->close();
$conn->close();
include 'template/footer.php';
?>
