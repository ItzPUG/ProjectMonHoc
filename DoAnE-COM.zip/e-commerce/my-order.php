<?php
session_start();
require 'conn/connect.php';
include 'template/header.php';
include 'template/nav.php';

// Kiểm tra xem người dùng đã đăng nhập chưa
if (!isset($_SESSION['user_id'])) {
    echo "<div class='container'><h1 class='donhang'>My Orders</h1><p style='text-align: center;'>Bạn cần phải đăng nhập để có thể xem đơn hàng.</p></div>";
    include 'template/footer.php';
    exit(); // Ngừng xử lý nếu người dùng chưa đăng nhập
}
$user_id = $_SESSION['user_id'];
$sql = "SELECT o.id AS order_id, o.timestamp AS order_date, o.orderstatus AS status, o.totalprice AS total_price, o.paymentmode AS payment_method
        FROM orders o
        WHERE o.user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Orders</title>
    <style>
        .container {
            margin-top: 30px;
        }
        .donhang {
            text-align: center;
            margin-bottom: 20px;
            color: #007bff;
        }
        .table th, .table td {
            text-align: center;
            vertical-align: middle;
        }
        .table th {
            background-color: #f8f9fa;
        }
        .btn-view, .btn-cancel {
            text-decoration: none;
            padding: 5px 10px;
            border-radius: 5px;
        }
        .btn-view {
            background-color: #28a745;
            color: white;
        }
        .btn-cancel {
            background-color: #dc3545;
            color: white;
        }
        .btn-view:hover, .btn-cancel:hover {
            opacity: 0.8;
        }
    </style>
    <script>
        function cancelOrder(orderId) {
            if (confirm("Bạn có chắc chắn muốn hủy đơn hàng này không?")) {
                window.location.href = 'cancel-order.php?order_id=' + orderId;
            }
        }
    </script>
</head>
<body>

<div class="container">
    <h1 class="donhang">Đơn hàng của tôi</h1>
    <table class="table table-striped table-bordered">
        <thead>
            <tr>
                <th>Mã đơn hàng</th>
                <th>Ngày giao dịch</th>
                <th>Trạng thái đơn hàng</th>
                <th>Phương thức thanh toán</th>
                <th>Tổng số tiền</th>
                <th>Xử lý</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row['order_id'] . "</td>";
                    echo "<td>" . $row['order_date'] . "</td>";
                    echo "<td>" . $row['status'] . "</td>";
                    echo "<td>" . $row['payment_method'] . "</td>";
                    echo "<td>" . $row['total_price'] . " USD</td>";
                    echo "<td><a href='view-order.php?order_id=" . $row['order_id'] . "' class='btn-view'>View</a> | <button class='btn-cancel' onclick='cancelOrder(" . $row['order_id'] . ")'>Cancel</button></td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='6'>No orders found</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>

<?php
$stmt->close();
$conn->close();
include 'template/footer.php';
?>
