<?php
session_start();
include('conn/connect.php');

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php'); // Kiểm tra người dùng đã đăng nhập
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') { //được submit từ form của index.php
    $user_id = $_SESSION['user_id'];
    $product_id = $_POST['product_id'];
    $quantity = $_POST['quantity'];

    $sql = "SELECT id FROM cart WHERE user_id = $user_id AND product_id = $product_id";
    $res = mysqli_query($conn, $sql);

    if ($res->num_rows > 0) {
        // Nếu sản phẩm đã tồn tại, cập nhật số lượng
        $sql = "UPDATE cart SET quantity = quantity + $quantity WHERE user_id = $user_id AND product_id = $product_id";
        $res = mysqli_query($conn, $sql);
    } else {
        // Nếu sản phẩm chưa tồn tại, thêm sản phẩm mới
        $sql = "INSERT INTO cart (user_id, product_id, quantity) VALUES ($user_id, $product_id, $quantity)";
        $res = mysqli_query($conn, $sql);
    }
}

header('Location: card.php');
exit;