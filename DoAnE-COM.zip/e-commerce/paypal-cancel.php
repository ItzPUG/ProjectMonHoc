<?php
session_start();
require 'conn/connect.php';

if (isset($_GET['order_id'])) {
    $order_id = intval($_GET['order_id']);

    // Xóa đơn hàng tạm thời và các mặt hàng liên quan
    $sql_delete_items = "DELETE FROM orderitems WHERE order_id = $order_id";
    mysqli_query($conn, $sql_delete_items);

    $sql_delete_order = "DELETE FROM orders WHERE id = $order_id AND orderstatus = 'Pending'";
    mysqli_query($conn, $sql_delete_order);

    echo "<script>alert('Thanh toán bị hủy! Đơn hàng đã bị xóa.'); window.location.href = 'card.php';</script>";
} else {
    echo "<script>alert('Không tìm thấy đơn hàng để hủy.'); window.location.href = 'card.php';</script>";
}
?>
