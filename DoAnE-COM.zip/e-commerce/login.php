<?php
session_start();

include('C:/xampp/htdocs/e-commerce/conn/connect.php'); 
include 'C:/xampp/htdocs/e-commerce/template/header.php'; 
include 'C:/xampp/htdocs/e-commerce/template/nav.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['username']) && $_POST['username'] != "") {
        $username = $_POST['username'];
        $password = $_POST['password'];

        // Thêm type vào truy vấn
        $stmt = $conn->prepare("SELECT id, password, type FROM users WHERE username = ?"); 
        $stmt->bind_param("s", $username);
        $stmt->execute(); 
        $stmt->store_result();
        $stmt->bind_result($user_id, $hashed_password, $user_type);

        if ($stmt->num_rows > 0) { // Tìm thấy username 
            $stmt->fetch();
            if (password_verify($password, $hashed_password)) {
                // Lưu thông tin vào session
                $_SESSION['user_id'] = $user_id; 
                $_SESSION['username'] = $username;
                $_SESSION['type'] = $user_type; // Lưu loại tài khoản
                
                // Chuyển hướng dựa trên loại tài khoản
                if ($user_type === 'admin') {
                    header('Location: ad-index.php');
                } else {
                    header('Location: index.php');
                }
                exit;
            } else {
                $mess = "Sai mật khẩu";
            }
        } else {
            $mess = "Tên người dùng không tồn tại.";
        }
    }
}
?>
<div class="container"> 
<div class="row">
<div class="content-blog">
<div class="col-md-offset-3 col-md-6"> <div class="panel panel-default">
<div class="panel-body">
<form method="post"> <div class="text-center"> <h3><b><i>ĐĂNG NHẬP</i></b></h3>
<img src="https://i.imgur.com/WpsqQq3.gif" alt="LoginImage" style="width:500px;height:200px;">
</div>
<div class="form-group">
<lable>Username</lable>
<input type="text" name="username" class="form-control" placeholder="Enter User name" required> </div>
<div class="form-group">
<lable>Password</lable>
<input type="password" name="password" placeholder="Enter Password" class="form-control" required> </div>
<button type="submit" class="btn btn-primary">Login</button>
<button type="button" class="btn btn-info" onclick="window.location.href='index.php'">Cancel</button>
<div class="alert alert-danger"><i>Bạn chưa có tài khoản?<a href="register.php"> Đăng kí</a> </i></div>
</form><br>
<?php
if (isset($mess) && $mess!=""){
?>

<div class="alert alert-danger">
<strong> Cảnh báo </strong><?php echo $mess?>.
</div>
<?php
}
?>
</div>
</div>
</div>
</div>
</div>
</div>
<?php
include 'C:/xampp/htdocs/e-commerce/template/footer.php';
?>