<?php
session_start();
include('conn/connect.php');
include('template/header.php');
include('template/nav.php');
?>
<style>
/* Định nghĩa style cho class image-container */
.image-container {
    width: 200px;
    height: 200px;
    overflow: hidden; /* Ẩn phần thừa của ảnh nếu lớn hơn khung */
    margin: 0 auto; /* Căn giữa khung ảnh */
}

/* Định nghĩa style cho thẻ img bên trong .image-container */
.image-container img {
    width: 100%;
    height: 100%;
    object-fit: contain; /* Giữ nguyên tỷ lệ và hiển thị toàn bộ ảnh */
}
.caption {
    margin-left: 20px;
}
</style>

<div class="container">
    <div class="row">
        <?php
        // Lấy id danh mục từ URL nếu có
        $category_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

        // Thực hiện câu truy vấn dựa trên id danh mục
        $sql = "SELECT * FROM products";
        if ($category_id > 0) {
            $sql .= " WHERE catid = $category_id";
        }
        $res = mysqli_query($conn, $sql);

        // Kiểm tra nếu có dữ liệu trả về
        if ($res && mysqli_num_rows($res) > 0) {
            while ($r = mysqli_fetch_array($res)) {
                ?>
                <div class="col-sm-6 col-md-3"> <!-- 4 ảnh trên dòng -->
                    <div class="image-container">
                        <a href="deltailitem.php?id=<?php echo $r['id'] ?>">
                            <img src="images/<?php echo htmlspecialchars($r['image']) ?>" class="rounded" alt="<?php echo htmlspecialchars($r['title']) ?>">
                        </a>
                    </div>
                    <div class="caption">
                        <form method="POST" action="addtocart.php">
                            <h4><?php echo htmlspecialchars($r['title']) ?></h4>
                            <p><?php echo htmlspecialchars($r['price']) ?> USD</p>
                            <p>Số lượng:  <input type="number" name="quantity" value="1" min="1" style="width: 50px;"></p>
                            <input type="hidden" name="product_id" value="<?php echo htmlspecialchars($r['id']) ?>">
                            <p><button type="submit" class="btn btn-primary">Thêm vào giỏ hàng</button></p>
                        </form>
                    </div>
                </div>
                <?php
            }
        } else {
            echo "<p>No products found.</p>";
        }
        ?>
    </div>
    <p style="text-align: right;"><a href="card.php" class="btn btn-danger">Xem giỏ hàng</a></p>
</div>

<?php
include('template/footer.php');
?>
