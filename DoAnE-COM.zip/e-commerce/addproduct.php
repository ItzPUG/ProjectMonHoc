<?php
session_start();
include('conn/connect.php');
include('template/header.php');
include('template/nav.php');

// Kiểm tra nếu người dùng không phải admin
if (!isset($_SESSION['type']) || $_SESSION['type'] !== 'admin') {
    header("Location: index.php"); // Chuyển hướng về trang chủ
    exit();
}

// Xử lý form thêm sản phẩm
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $price = $_POST['price'];
    $category = $_POST['category'];
    $image = $_FILES['image']['name'];
    $temp_image = $_FILES['image']['tmp_name'];
    $description = $_POST['description'];

    // Kiểm tra nếu giá sản phẩm là số âm
    if ($price < 0) {
        $error_message = "Giá sản phẩm không thể là số âm!";
    } else {
        // Di chuyển ảnh lên thư mục images
        move_uploaded_file($temp_image, "images/" . $image);

        // Thực hiện câu lệnh SQL để thêm sản phẩm vào cơ sở dữ liệu
        $sql = "INSERT INTO products (title, price, catid, image, description) VALUES ('$title', '$price', '$category', '$image', '$description')";
        if (mysqli_query($conn, $sql)) {
            echo "<script>alert('Sản phẩm đã được thêm thành công!'); window.location.href = 'ad-index.php';</script>";
        } else {
            echo "<script>alert('Có lỗi xảy ra. Vui lòng thử lại.');</script>";
        }
    }
}

// Lấy danh sách các danh mục sản phẩm để hiển thị trong form
$sql_cat = "SELECT * FROM category";
$res_cat = mysqli_query($conn, $sql_cat);
?>
<div class="container">
    <h1 class="text-center">Thêm Sản Phẩm Mới</h1>

    <?php
    // Hiển thị thông báo lỗi nếu có
    if (isset($error_message)) {
        echo "<div class='alert alert-danger'>$error_message</div>";
    }
    ?>

    <form method="POST" enctype="multipart/form-data">
        <div class="form-group">
            <label for="title">Tên sản phẩm</label>
            <input type="text" class="form-control" id="title" name="title" required>
        </div>
        <div class="form-group">
            <label for="price">Giá sản phẩm</label>
            <input type="number" class="form-control" id="price" name="price" required>
        </div>
        <div class="form-group">
            <label for="category">Danh mục sản phẩm</label>
            <select class="form-control" id="category" name="category" required>
                <?php while ($r_cat = mysqli_fetch_assoc($res_cat)) { ?>
                    <option value="<?php echo $r_cat['id']; ?>"><?php echo $r_cat['name']; ?></option>
                <?php } ?>
            </select>
        </div>
        <div class="form-group">
            <label for="image">Ảnh sản phẩm</label>
            <input type="file" class="form-control" id="image" name="image" required>
        </div>
        <div class="form-group">
            <label for="description">Mô tả sản phẩm</label>
            <textarea class="form-control" id="description" name="description" rows="3" required></textarea>
        </div>
        <button type="submit" class="btn btn-success">Thêm sản phẩm</button>
        <a href="ad-index.php" class="btn btn-danger">Hủy</a>
    </form>
</div>

<?php
include('template/footer.php');
?>
