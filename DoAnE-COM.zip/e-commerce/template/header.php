<!DOCTYPE html>
<html>
<head>
<title>Thực hành TMDT</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <style>
        .jumbotron {
            background: linear-gradient(45deg, #ff9a9e, #fecfef); /* Màu gradient 2 */
            color: white;
        }
        h1{
            font-style: italic;
        }
    </style>
</head>
<body>
<div class="container" style="height: 150px;">
<div class="jumbotron" style="margin-bottom: 0px; margin-top: 0px; height: 150px; padding-top:10px"> 
    <h1>ALPACA</h1>
<p></p>
</div>
</div>
</body>
</html>
