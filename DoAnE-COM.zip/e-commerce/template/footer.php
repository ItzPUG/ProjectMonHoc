<html>
<div class="container">
<div class="jumbotron" style="height: 150px; padding-top: 10px; font-size: 20px; text-align: center"> <h4><i>Thông tin liên hệ</i></h1>
<h5>Email: duongtrongphuc@mku.edu.vn</h5>
<h5>Phone: 0938111111</h5>
<h5>Fax: 0938111111</h5>
</div>
</div>
</body>
</html>