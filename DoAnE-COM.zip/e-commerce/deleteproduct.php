<?php
session_start();
include('conn/connect.php');

// Kiểm tra nếu người dùng không phải admin
if (!isset($_SESSION['type']) || $_SESSION['type'] !== 'admin') {
    header("Location: index.php"); // Chuyển hướng về trang chủ
    exit();
}

// Lấy id sản phẩm từ URL
$product_id = isset($_GET['id']) ? $_GET['id'] : 0;

// Xóa các dòng liên quan trong bảng orderitems
$sql_delete_orderitems = "DELETE FROM orderitems WHERE product_id = $product_id";
if (mysqli_query($conn, $sql_delete_orderitems)) {
    // Sau khi xóa dòng trong orderitems, tiếp tục xóa sản phẩm
    $sql_delete_product = "DELETE FROM products WHERE id = $product_id";
    if (mysqli_query($conn, $sql_delete_product)) {
        echo "<script>alert('Sản phẩm đã được xóa!'); window.location.href = 'ad-index.php';</script>";
    } else {
        echo "<script>alert('Có lỗi xảy ra khi xóa sản phẩm.'); window.location.href = 'ad-index.php';</script>";
    }
} else {
    echo "<script>alert('Không thể xóa sản phẩm vì dữ liệu liên quan.'); window.location.href = 'ad-index.php';</script>";
}
?>
